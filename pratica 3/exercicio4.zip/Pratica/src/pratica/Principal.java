
package pratica;

import java.util.Scanner;

public class Principal {

    public static void main(String[] args) {
        Scanner ler = new Scanner(System.in);
    
    int x = 4;
        int vetor[] = new int[x];
        int i;

        for (i = 0; i < x; i++) {
            System.out.printf("informe %dº valor de %d: ", (i + 1), x);
            vetor[i] = ler.nextInt();
        }

        for (i = vetor.length - 1; i >= 0; i--) {
            System.out.print(vetor[i] + " ");
        }
    }
}

