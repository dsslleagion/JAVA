
package senha;

public class Empresa {

    public static void main(String[] args) {
        Gerente g1;
        
        g1 = new Gerente(6321, "João da Silva", 63215463, 7500.40);
        g1.getSenha();
        g1.getNome();
        g1.getCpf();
        g1.getSalario();
        g1.setSenha(4321);
        g1.setNome("João da Silva");
        g1.imprimir();
        }
    }
