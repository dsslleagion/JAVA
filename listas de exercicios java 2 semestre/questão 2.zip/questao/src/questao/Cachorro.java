/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package questao;

/**
 *
 * @author User
 */
public class Cachorro extends Animal {
    private String raca;

    public Cachorro(String raca, String nome, double peso) {
        super(nome, peso);
        this.raca = raca;
    }

    public String getRaca() {
        return raca;
    }

    public void setRaca(String raca) {
        this.raca = raca;
    }
    public void imprimir(){ 
        super.imprimir();
            System.out.println(raca);
}

}
