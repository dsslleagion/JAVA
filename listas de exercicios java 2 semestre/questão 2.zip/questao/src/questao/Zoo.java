
package questao;

public class Zoo {

    public static void main(String[] args) {
        Cachorro c1;
        Peixe p1;
        
        c1 = new Cachorro ("Pastor", "Edir", 666);
        c1.getRaca();
        c1.getNome();
        c1.getPeso();
        c1.imprimir();
        
        p1 = new Peixe ("Atlantico", "Tubanao", 4000);
        p1.getTipoHabitat();
        p1.getNome();
        p1.getPeso();
        p1.imprimir();
        
    }
    
}
