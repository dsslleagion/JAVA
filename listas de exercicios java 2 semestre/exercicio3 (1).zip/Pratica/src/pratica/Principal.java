
package pratica;

import java.util.Scanner;

public class Principal {

    public static void main(String[] args) {
        Scanner ler = new Scanner(System.in);
    
    int x = 10;
        int vetor[] = new int[x];
        int pares[] = new int[x];
        int i;
        int nums = 0;
        int maior = Integer.MIN_VALUE;
        float media = 0;
        
        for (i = 0; i < x; i++) {
            System.out.printf("Informe %dº valor de %d: ", (i + 1), x);
            vetor[i] = ler.nextInt();  
        }       
       
        for (i=0; i < x; i++){
            if (vetor[i] %2 == 0) {
                pares[i] = vetor[i];
                nums = nums + 1;
            }
        }
        
        for (i=0; i < x; i++){
            if (pares[i] > maior) {
                maior = pares[i];
            }
        }
               
        for (i=0; i < x; i++){
            media = media + pares[i];            
        }
        
        System.out.printf("Numeros pares: " + nums);
        System.out.println();
        System.out.printf("Maior número: " + maior);
        System.out.println();
        media = media / nums;
        System.out.printf("A média do vetor é: %.1f", media);        
    }
}

