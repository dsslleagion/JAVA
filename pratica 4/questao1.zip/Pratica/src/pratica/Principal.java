
package pratica;

public class Principal {

    public static void main(String[] args) {
       Funcionario fun1;
       
       fun1 = new Funcionario (1500, "Juliana", "456789231");
       fun1.aumentar_Salario();
       fun1.imprimir();
    }
    
}
