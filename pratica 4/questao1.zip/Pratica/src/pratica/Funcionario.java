/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pratica;

/**
 *
 * @author User
 */
public class Funcionario extends Pessoa {
    private double salario;

    public Funcionario(double salario, String nome, String rg) {
        super(nome, rg);
        this.salario = salario;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }
    public double aumentar_Salario(){
        double sal;
        sal = 1.1 * salario;
        return sal;
    }
    public void imprimir(){
        System.out.println("Nome: "+nome);
        System.out.println("RG: "+rg);
        System.out.println("Salario: "+aumentar_Salario());
        System.out.println("-----------------------------");
    }
}
